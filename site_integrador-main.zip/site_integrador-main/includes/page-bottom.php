<footer class="text-warning bg-danger">
    <div class="container">
        <div class="row">
            <div class="col" style="text-align: center;">
                <img class="mb-2" src="./img/ham-ico-64.png" width="64" height="64" >
                <span class="display-5">Larika</span>
                <small class="d-block mb-3">&copy;2025</small>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
