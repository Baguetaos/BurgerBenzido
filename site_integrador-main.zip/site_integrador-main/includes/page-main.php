<main class="container p-3">
    <div class="row">
        <div class="col">
            <div class="card text-white bg-warning">
                <img class="card-img-top" src="./img/hamburger-cartoon-w358.png">
            </div>
            <div class="card-body">
                <p class="card-text">Prove o hamburguer da casa.</p>
            </div>
        </div>

        <div class="col">
            <div class="card text-white bg-warning">
                <img class="card-img-top" src="./img/hotdog-cartoon-w358.png">
            </div>
            <div class="card-body">
                <p class="card-text">Prove o Hot Dog da casa.</p>
            </div>
        </div>

        <div class="col">
            <div class="card text-white bg-warning">
                <img class="card-img-top" src="./img/potato-cartoon-w358.png">
            </div>
            <div class="card-body">
                <p class="card-text">Prove as nossas batatas recheadas</p>
            </div>
        </div>

        <div class="col">
            <div class="card text-white bg-warning">
                <img class="card-img-top" src="./img/snacks-cartoon-w358.png">
            </div>
            <div class="card-body">
                <p class="card-text">Prove os nossos petiscos.</p>
            </div>
        </div>
    </div>
</main>
